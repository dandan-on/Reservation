package kr.or.connect.reservation.service;

import kr.or.connect.reservation.service.security.UserDbService;

public interface UserService extends UserDbService {
	Long getUserId(String email);
}
