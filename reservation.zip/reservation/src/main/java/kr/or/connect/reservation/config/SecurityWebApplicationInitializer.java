package kr.or.connect.reservation.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

//스프링 시큐리티가 제공하는 필터들을 사용하기 위한 설정 파일
public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {
	
}
