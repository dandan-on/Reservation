package kr.or.connect.reservation.service;

import java.util.List;

import kr.or.connect.reservation.dto.CategoriesResult;

public interface CategoryService {
	public List<CategoriesResult> getCategoryList();

}
