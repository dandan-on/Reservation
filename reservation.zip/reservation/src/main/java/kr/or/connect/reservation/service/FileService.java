package kr.or.connect.reservation.service;

import java.util.Map;

public interface FileService {
	Map<String, Object> getFileInfo(Long fileId);
}
